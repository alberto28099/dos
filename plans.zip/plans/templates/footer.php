<div class="clearfix"></div>
	<!-- Footer -->
    <footer>
    	<div class="container-fluid">
    		<p class="text-center">Copyright  <?php echo date("Y")?></p>
    	</div>
    </footer>
    <!-- /Footer -->
  </body>
</html>
<?php ob_end_flush(); ?>
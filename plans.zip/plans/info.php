<?php require_once 'templates/header.php';?>
	<div class="content">
     	<div class="container">
     		<div class="col-md-8 col-sm-8 col-xs-12">
     			<h2>Gestione sus negocios</h2>
	     		<div>
				Comience su negocio o empresa organizado desde el principio. 
				SEMIWS es verdaderamente la solución en términos de tecnología y presupuesto. 
				Hemos desarrollado un software de calidad y accesible para todos. 
				Ahora tener su propio software de gestión empresarial es como pagar 
				un recibo de luz, todo lo que necesita es un dispositivo con conexión a Internet.
				</div>
				<br>
     			<div class="embed-responsive embed-responsive-16by9">
				  
				</div>
				<br><br>
				
     		</div>
     		
     		
     		<?php require_once 'templates/sidebar.php';?>
     		
     	</div>
    </div> <!-- /container -->
<?php require_once 'templates/footer.php';?>
	


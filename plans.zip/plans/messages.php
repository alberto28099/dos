<?php
define('FIELDS_MISSING', 'Algunos campos faltan');
define('PASSWORD_NOT_MATCH', 'Las contraseñas no coinciden');
define('USER_REGISTRATION_FAIL', 'Registro de usuarios falló');
define('USER_REGISTRATION_SUCCESS', 'Registro de usuario se ha realizado correctamente , puede iniciar sesión ahora');


define('LOGIN_FIELDS_MISSING', 'Correo electrónico y contraseña faltan');
define('LOGIN_FAIL', 'Correo electrónico y/o Contraseña no coinciden');

define('PASSOWRD_CHANAGE_SUCCESS', 'Contraseña cambiada con éxito.');
